#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <string> // Added for std::getline

using namespace std;

// Definition of structure course
struct Course {
    string courseNumber;
    string name;
    vector<string> prerequisites;
};

// Function to split string into a list of strings based on a given delimiter
vector<string> tokenize(string s, string del = " ") {
    vector<string> stringArray;
    size_t start = 0;
    size_t end = s.find(del);

    while (end != string::npos) {
        stringArray.push_back(s.substr(start, end - start));
        start = end + del.size();
        end = s.find(del, start);
    }

    stringArray.push_back(s.substr(start, end - start));
    return stringArray;
}

// Function to load file and store the details into a list of courses
vector<Course> loadDataStructure() {
    ifstream fin("abcu.txt");
    if (!fin) {
        cerr << "Error opening file abc.txt\n";
        return vector<Course>();
    }

    vector<Course> courses;
    string line;

    while (getline(fin, line)) {
        if (line == "-1") {
            break;
        }

        Course course;
        vector<string> tokenizedInformation = tokenize(line, ",");

        course.courseNumber = tokenizedInformation[0];
        course.name = tokenizedInformation[1];

        for (size_t i = 2; i < tokenizedInformation.size(); i++) {
            course.prerequisites.push_back(tokenizedInformation[i]);
        }

        courses.push_back(course);
    }

    fin.close();
    return courses;
}

// Printing course information of a given course in proper format
void printCourse(const Course& course) {
    cout << "Course Number: " << course.courseNumber << endl;
    cout << "Course Name: " << course.name << endl;
    cout << "Prerequisites: ";
    for (const auto& prerequisite : course.prerequisites) {
        cout << prerequisite << " ";
    }
    cout << "\n\n";
}

// Printing course information of all courses in proper format
void printCourseList(const vector<Course>& courses) {
    vector<Course> sortedCourses = courses;
    sort(sortedCourses.begin(), sortedCourses.end(), [](const Course& a, const Course& b) {
        return a.courseNumber < b.courseNumber;
        });

    for (const auto& course : sortedCourses) {
        printCourse(course);
    }
}

// Search for a course using the user-entered course number
void searchCourse(const vector<Course>& courses) {
    string courseNumber;
    cout << "Enter course number: ";
    cin >> courseNumber;

    bool found = false;
    for (const auto& course : courses) {
        if (course.courseNumber == courseNumber) {
            found = true;
            printCourse(course);
            break;
        }
    }

    if (!found) {
        cout << "Course with given course number not found\n";
    }
}

int main() {
    vector<Course> courses;
    int choice;

    do {
        cout << "1. Load Data Structure\n";
        cout << "2. Print Course List\n";
        cout << "3. Print Course\n";
        cout << "4. Exit\n";
        cout << "\nEnter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            courses = loadDataStructure();
            break;
        case 2:
            printCourseList(courses);
            break;
        case 3:
            searchCourse(courses);
            break;
        case 4:
            cout << "Exit\n";
            break;
        default:
            cout << "Invalid Choice\n";
            break;
        }
    } while (choice != 4);

    return 0;
}
